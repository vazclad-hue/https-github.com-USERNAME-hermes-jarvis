# Welcome to Hermes Vault

This is your **Obsidian-compatible** markdown vault.

- Open [[Ideas]]
- Track [[Projects]]
- Review [[Archive]]

#mission-control #welcome
