# HERMES Mission Control / J.A.R.V.I.S.

A self-hosted mission-control dashboard with AI chat, system telemetry, tasks, and an Obsidian-compatible Markdown vault.

## Run locally

```bash
python -m pip install -r requirements.txt
python server.py
```

Open <http://localhost:5000> and configure an AI provider in **Settings**.

## Providers

- Groq
- OpenRouter
- Ollama / Hermes (local)

API keys are not committed. Add yours through Settings after launch.
